const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import SiteHeader from '@/components/SiteHeader';
import SiteFooter from '@/components/SiteFooter';
import TopicDrawer from '@/components/TopicDrawer';
import PostCard from '@/components/PostCard';

import { useAuth } from '@/lib/AuthContext';

const ALL = '전체';

function SkeletonCard() {
  return (
    <div className="animate-pulse border border-border px-5 py-6 sm:px-8 sm:py-8">
      <div className="h-2 w-20 bg-border/60" />
      <div className="mt-4 h-6 w-2/3 bg-border/60" />
      <div className="mt-3 h-3 w-full bg-border/40" />
      <div className="mt-2 h-3 w-4/5 bg-border/40" />
    </div>
  );
}

export default function PostList() {
  const { user } = useAuth();
  const isAdmin = user?.role === 'admin';
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [active, setActive] = useState(ALL);
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    db.entities.Post.list({ sort: '-created_date', limit: 200 })
      .then((res) => setPosts(res?.items ?? res ?? []))
      .finally(() => setLoading(false));
  }, []);

  const topics = useMemo(() => {
    const counts = new Map();
    posts.forEach((post) => {
      const name = post.topic || '기록';
      counts.set(name, (counts.get(name) || 0) + 1);
    });
    return [
      { name: ALL, count: posts.length },
      ...Array.from(counts, ([name, count]) => ({ name, count })),
    ];
  }, [posts]);

  const visible = active === ALL ? posts : posts.filter((post) => (post.topic || '기록') === active);

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader onMenuClick={() => setDrawerOpen(true)} writeTo={isAdmin ? '/write' : undefined} />

      <main className="mx-auto max-w-5xl px-5 pb-16 sm:px-10">
        <section className="border-b border-border py-14 sm:py-20">
          <h1 className="font-heading text-[clamp(2.1rem,6.5vw,3.6rem)] font-semibold leading-[1.15] tracking-tight">
            {active === ALL ? '기록' : active}
          </h1>
          <div className="mt-4 flex flex-wrap items-center gap-x-4 gap-y-2 text-[13px] text-muted-foreground">
            <span>{loading ? '불러오는 중' : `글 ${visible.length}편`}</span>
            {active !== ALL ? (
              <button
                type="button"
                onClick={() => setActive(ALL)}
                className="inline-flex items-center gap-2 border border-border px-2.5 py-1 text-[11px] tracking-[0.12em] transition-colors hover:border-foreground"
              >
                {active} <span className="text-[13px] leading-none">×</span>
              </button>
            ) : null}
          </div>
        </section>

        <section className="mt-8 space-y-4 sm:mt-12 sm:space-y-5">
          {loading ? (
            <>
              <SkeletonCard />
              <SkeletonCard />
              <SkeletonCard />
            </>
          ) : null}

          {!loading && visible.map((post) => (
            <PostCard key={post.id} post={post} />
          ))}

          {!loading && visible.length === 0 ? (
            <div className="border border-border px-6 py-20 text-center">
              <p className="text-[14px] text-muted-foreground">
                {posts.length === 0 ? '아직 글이 없습니다.' : '아직 이 주제에 글이 없습니다.'}
              </p>
              {isAdmin && posts.length === 0 ? (
                <button
                  type="button"
                  onClick={() => setDrawerOpen(true)}
                  className="mt-6 inline-flex border border-foreground px-5 py-2.5 text-[11px] tracking-[0.16em] transition-colors hover:bg-foreground hover:text-background"
                >
                  첫 글 쓰기
                </button>
              ) : null}
            </div>
          ) : null}
        </section>
      </main>

      <SiteFooter />

      <TopicDrawer
        open={drawerOpen}
        onClose={() => setDrawerOpen(false)}
        topics={topics}
        active={active}
        onSelect={setActive}
        footer={
          isAdmin ? (
            <Link
              to="/write"
              className="flex w-full items-center justify-center border border-foreground px-4 py-3 text-[11px] tracking-[0.16em] transition-colors hover:bg-foreground hover:text-background"
            >
              새 글 쓰기
            </Link>
          ) : (
            <button
              type="button"
              onClick={() => db.auth.redirectToLogin('/write')}
              className="w-full text-left text-[10px] tracking-[0.18em] text-muted-foreground transition-colors hover:text-foreground"
            >
              관리자 로그인
            </button>
          )
        }
      />
    </div>
  );
}