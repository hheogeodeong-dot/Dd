const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useEffect, useState } from 'react';
import { Link, Navigate, useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft, Loader2 } from 'lucide-react';
import SiteHeader from '@/components/SiteHeader';
import WriteKeyGate from '@/components/WriteKeyGate';

import { useAuth } from '@/lib/AuthContext';

const EMPTY = { title: '', topic: '', content: '' };
const UNLOCK_KEY = 'nksxagn-write-unlocked';

export default function Write() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user, isAuthenticated, isLoadingAuth, authChecked } = useAuth();
  const isAdmin = user?.role === 'admin';

  const [unlocked, setUnlocked] = useState(
    () => sessionStorage.getItem(UNLOCK_KEY) === '1'
  );
  const [form, setForm] = useState(EMPTY);
  const [loading, setLoading] = useState(Boolean(id));
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!authChecked || isLoadingAuth) return;
    if (!isAuthenticated) db.auth.redirectToLogin(id ? `/write/${id}` : '/write');
  }, [authChecked, isLoadingAuth, isAuthenticated, id]);

  useEffect(() => {
    if (!id) return;
    db.entities.Post.get(id)
      .then((post) => {
        if (post) setForm({ title: post.title || '', topic: post.topic || '', content: post.content || '' });
      })
      .finally(() => setLoading(false));
  }, [id]);

  if (authChecked && isAuthenticated && !isAdmin) return <Navigate to="/list" replace />;

  const update = (field) => (event) => setForm((prev) => ({ ...prev, [field]: event.target.value }));

  const submit = async (event) => {
    event.preventDefault();
    if (saving) return;
    if (!form.title.trim() || !form.content.trim()) {
      setError('제목과 본문을 모두 적어 주세요.');
      return;
    }
    setSaving(true);
    setError('');
    try {
      const payload = {
        title: form.title.trim(),
        topic: form.topic.trim() || '기록',
        content: form.content,
      };
      if (id) {
        await db.entities.Post.update(id, payload);
        navigate(`/post/${id}`);
      } else {
        const created = await db.entities.Post.create(payload);
        navigate(`/post/${created.id}`);
      }
    } catch (err) {
      setError('저장하지 못했습니다. 잠시 후 다시 시도해 주세요.');
      setSaving(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader onMenuClick={() => navigate('/list')} />

      <main className="mx-auto max-w-2xl px-5 pb-28 pt-14 sm:px-8 sm:pt-20">
        <Link
          to={id ? `/post/${id}` : '/list'}
          className="group inline-flex items-center gap-2 text-[11px] uppercase tracking-[0.2em] text-muted-foreground transition-colors hover:text-foreground"
        >
          <ArrowLeft className="h-4 w-4 transition-transform group-hover:-translate-x-0.5" strokeWidth={1.5} />
          돌아가기
        </Link>

        {!unlocked ? (
          <WriteKeyGate
            onUnlock={() => {
              sessionStorage.setItem(UNLOCK_KEY, '1');
              setUnlocked(true);
            }}
          />
        ) : (
          <>
        <div className="mt-10">
          <span className="text-[10px] tracking-[0.22em] text-muted-foreground">{id ? '글 수정' : '새 글'}</span>
        </div>

        {loading ? (
          <div className="mt-10 flex items-center gap-2 text-[13px] text-muted-foreground">
            <Loader2 className="h-4 w-4 animate-spin" strokeWidth={1.5} />
            글을 불러오는 중
          </div>
        ) : (
          <form onSubmit={submit} className="mt-8">
            <input
              value={form.topic}
              onChange={update('topic')}
              placeholder="주제 (예: 일상)"
              maxLength={20}
              className="w-full border-0 border-b border-border bg-transparent pb-3 text-[12px] uppercase tracking-[0.22em] text-muted-foreground placeholder:text-muted-foreground/60 focus:border-foreground focus:outline-none"
            />
            <input
              value={form.title}
              onChange={update('title')}
              placeholder="제목"
              maxLength={120}
              className="mt-6 w-full border-0 border-b border-border bg-transparent pb-4 font-heading text-[clamp(1.6rem,5vw,2.4rem)] font-semibold leading-tight tracking-tight text-foreground placeholder:text-muted-foreground/40 focus:border-foreground focus:outline-none"
            />
            <textarea
              value={form.content}
              onChange={update('content')}
              placeholder="오늘 남기고 싶은 장면을 적어 보세요."
              rows={14}
              className="mt-6 w-full resize-none border-0 bg-transparent text-[16px] leading-[1.95] text-foreground placeholder:text-muted-foreground/50 focus:outline-none sm:text-[17px]"
            />

            {error ? <p className="mt-2 text-[13px] text-destructive">{error}</p> : null}

            <div className="mt-6 flex items-center justify-between border-t border-border pt-6">
              <span className="text-[11px] uppercase tracking-[0.2em] text-muted-foreground">
                {form.content.length.toLocaleString()}자
              </span>
              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={() => navigate(id ? `/post/${id}` : '/list')}
                  className="px-4 py-3 text-[11px] uppercase tracking-[0.2em] text-muted-foreground transition-colors hover:text-foreground"
                >
                  취소
                </button>
                <button
                  type="submit"
                  disabled={saving}
                  className="inline-flex items-center gap-2 border border-foreground px-6 py-3 text-[11px] uppercase tracking-[0.2em] transition-colors hover:bg-foreground hover:text-background disabled:opacity-50"
                >
                  {saving ? <Loader2 className="h-3.5 w-3.5 animate-spin" strokeWidth={1.5} /> : null}
                  {saving ? '저장 중' : '발행'}
                </button>
              </div>
            </div>
          </form>
        )}
          </>
        )}
      </main>
    </div>
  );
}