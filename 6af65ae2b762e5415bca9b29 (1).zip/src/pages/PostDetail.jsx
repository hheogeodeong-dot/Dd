const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft, Trash2 } from 'lucide-react';
import moment from 'moment';
import 'moment/locale/ko';
import SiteHeader from '@/components/SiteHeader';
import PageNotFound from '@/lib/PageNotFound';

import { useAuth } from '@/lib/AuthContext';

moment.locale('ko');

export default function PostDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const isAdmin = user?.role === 'admin';
  const [post, setPost] = useState(null);
  const [loading, setLoading] = useState(true);
  const [missing, setMissing] = useState(false);
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    setLoading(true);
    db.entities.Post.get(id)
      .then((record) => {
        if (!record) setMissing(true);
        else setPost(record);
      })
      .catch(() => setMissing(true))
      .finally(() => setLoading(false));
  }, [id]);

  useEffect(() => {
    if (!missing) return undefined;
    const meta = document.createElement('meta');
    meta.name = 'prerender-status-code';
    meta.content = '404';
    document.head.appendChild(meta);
    return () => meta.remove();
  }, [missing]);

  const remove = async () => {
    if (!window.confirm('이 글을 삭제할까요? 되돌릴 수 없습니다.')) return;
    setDeleting(true);
    await db.entities.Post.delete(id);
    navigate('/list');
  };

  if (missing) return <PageNotFound />;

  const paragraphs = (post?.content || '').split(/\n{2,}/).filter(Boolean);

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader onMenuClick={() => navigate('/list')} writeTo={isAdmin ? '/write' : undefined} />

      <article className="mx-auto max-w-2xl px-5 pb-28 pt-14 sm:px-8 sm:pt-20">
        <div className="flex items-center justify-between">
          <Link
            to="/list"
            className="group inline-flex items-center gap-2 text-[11px] uppercase tracking-[0.2em] text-muted-foreground transition-colors hover:text-foreground"
          >
            <ArrowLeft className="h-4 w-4 transition-transform group-hover:-translate-x-0.5" strokeWidth={1.5} />
            목록
          </Link>
          {isAdmin && post ? (
            <div className="flex items-center gap-4 text-[11px] uppercase tracking-[0.2em]">
              <Link to={`/write/${post.id}`} className="text-muted-foreground transition-colors hover:text-foreground">
                수정
              </Link>
              <button
                type="button"
                onClick={remove}
                disabled={deleting}
                className="inline-flex items-center gap-1.5 text-muted-foreground transition-colors hover:text-destructive disabled:opacity-40"
              >
                <Trash2 className="h-3.5 w-3.5" strokeWidth={1.5} />
                삭제
              </button>
            </div>
          ) : null}
        </div>

        {loading ? (
          <div className="mt-16 animate-pulse space-y-4">
            <div className="h-3 w-32 bg-border/70" />
            <div className="h-9 w-4/5 bg-border/70" />
            <div className="h-3 w-full bg-border/50" />
            <div className="h-3 w-full bg-border/50" />
            <div className="h-3 w-2/3 bg-border/50" />
          </div>
        ) : null}

        {!loading && post ? (
          <>
            <div className="mt-10 flex items-center gap-3 text-[10px] uppercase tracking-[0.24em] text-muted-foreground">
              <span className="text-brand">{post.topic || '기록'}</span>
              <span className="h-[1px] w-6 bg-border" />
              <span className="font-mono tracking-[0.14em]">{moment(post.created_date).format('YYYY.MM.DD')}</span>
            </div>

            <h1 className="mt-5 font-heading text-[clamp(1.9rem,5.5vw,2.9rem)] font-semibold leading-[1.35] tracking-tight text-foreground">
              {post.title}
            </h1>

            <div className="mt-10 space-y-7 border-t border-border pt-10">
              {paragraphs.map((paragraph, index) => (
                <p key={index} className="whitespace-pre-line text-[16px] leading-[1.95] text-foreground/85 sm:text-[17px]">
                  {paragraph}
                </p>
              ))}
            </div>
          </>
        ) : null}
      </article>
    </div>
  );
}