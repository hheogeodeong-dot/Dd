import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Logo from '@/components/Logo';

export default function Splash() {
  const navigate = useNavigate();
  const [leaving, setLeaving] = useState(false);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const id = window.setTimeout(() => setReady(true), 60);
    return () => window.clearTimeout(id);
  }, []);

  const enter = () => {
    if (leaving) return;
    setLeaving(true);
    window.setTimeout(() => navigate('/list'), 780);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-background">
      {/* 열리는 커튼 */}
      <div
        className={`pointer-events-none absolute inset-x-0 top-0 h-1/2 bg-splash transition-transform duration-700 ease-[cubic-bezier(0.76,0,0.24,1)] ${
          leaving ? '-translate-y-full' : 'translate-y-0'
        }`}
      />
      <div
        className={`pointer-events-none absolute inset-x-0 bottom-0 h-1/2 bg-splash transition-transform duration-700 ease-[cubic-bezier(0.76,0,0.24,1)] ${
          leaving ? 'translate-y-full' : 'translate-y-0'
        }`}
      />

      <button
        type="button"
        onClick={enter}
        className="group absolute inset-0 z-10 flex flex-col items-center justify-center gap-6 focus:outline-none"
        aria-label="사이트로 들어가기"
      >
        <Logo
          className={`text-[clamp(1.7rem,7.5vw,4.5rem)] text-white transition-all duration-500 ${
            leaving
              ? 'scale-95 opacity-0 blur-[2px]'
              : ready
                ? 'scale-100 opacity-100'
                : 'scale-100 opacity-0'
          }`}
        />
        <span
          className={`flex flex-col items-center gap-3 transition-opacity duration-300 ${
            leaving ? 'opacity-0' : 'opacity-100'
          }`}
        >
          <span className="h-[1px] w-8 bg-white/25 transition-all duration-500 group-hover:w-16 group-hover:bg-white/60" />
          <span className="text-[9px] uppercase tracking-[0.5em] text-white/30 transition-colors duration-500 group-hover:text-white/70">
            enter
          </span>
        </span>
      </button>
    </div>
  );
}