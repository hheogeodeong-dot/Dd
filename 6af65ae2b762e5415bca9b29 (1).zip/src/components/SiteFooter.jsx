import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Instagram } from 'lucide-react';
import ClosingCurtains from '@/components/ClosingCurtains';

export default function SiteFooter() {
  const navigate = useNavigate();
  const [closing, setClosing] = useState(false);

  const goHome = (event) => {
    event.preventDefault();
    if (closing) return;
    setClosing(true);
    window.setTimeout(() => navigate('/'), 720);
  };

  return (
    <footer className="border-t border-border">
      <ClosingCurtains active={closing} />

      <div className="mx-auto flex max-w-5xl flex-col gap-5 px-5 py-10 sm:flex-row sm:items-center sm:justify-between sm:px-10 sm:py-12">
        <div className="flex flex-col gap-3">
          <a
            href="mailto:nonokasexagain@gmail.com"
            className="text-[13px] text-muted-foreground transition-colors hover:text-foreground"
          >
            nonokasexagain@gmail.com
          </a>
          <a
            href="https://instagram.com/nksxagn"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="인스타그램 @nksxagn"
            className="text-muted-foreground transition-colors hover:text-foreground"
          >
            <Instagram className="h-[18px] w-[18px]" strokeWidth={1.5} />
          </a>
        </div>

        <a
          href="/"
          onClick={goHome}
          className="self-start text-[11px] tracking-[0.16em] text-muted-foreground transition-colors hover:text-foreground sm:self-auto"
        >
          처음 화면으로
        </a>
      </div>
    </footer>
  );
}