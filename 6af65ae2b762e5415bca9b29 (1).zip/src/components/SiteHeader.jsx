import { Link } from 'react-router-dom';
import { Menu, PenLine } from 'lucide-react';
import Logo from '@/components/Logo';

export default function SiteHeader({ onMenuClick, writeTo }) {
  return (
    <header className="sticky top-0 z-40 border-b border-border bg-background/85 backdrop-blur-md">
      <div className="relative mx-auto flex h-16 max-w-5xl items-center justify-between px-5 sm:h-20 sm:px-10">
        <button
          type="button"
          onClick={onMenuClick}
          className="group flex items-center gap-2.5 py-2 text-muted-foreground transition-colors hover:text-foreground"
          aria-label="주제별 목록 열기"
        >
          <Menu className="h-[18px] w-[18px]" strokeWidth={1.5} />
          <span className="hidden text-[11px] uppercase tracking-[0.22em] sm:inline">목록</span>
        </button>

        <Link
          to="/list"
          className="absolute left-1/2 -translate-x-1/2 py-2 text-foreground transition-opacity hover:opacity-70"
          aria-label="글 목록으로"
        >
          <Logo className="text-[18px] sm:text-[21px]" />
        </Link>

        <div className="flex min-w-[32px] justify-end sm:w-24">
          {writeTo ? (
            <Link
              to={writeTo}
              className="group flex items-center gap-2 py-2 text-foreground transition-colors hover:text-muted-foreground"
              aria-label="글 쓰기"
            >
              <PenLine className="h-[15px] w-[15px]" strokeWidth={1.5} />
              <span className="hidden text-[11px] font-medium uppercase tracking-[0.18em] sm:inline">
                글쓰기
              </span>
            </Link>
          ) : null}
        </div>
      </div>
    </header>
  );
}