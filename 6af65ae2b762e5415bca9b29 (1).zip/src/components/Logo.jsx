import { cn } from '@/lib/utils';

export default function Logo({ className }) {
  return (
    <span
      className={cn(
        'select-none font-body font-bold lowercase leading-none tracking-[-0.035em]',
        className
      )}
    >
      nonok<span className="text-brand">a</span>sexagain
    </span>
  );
}