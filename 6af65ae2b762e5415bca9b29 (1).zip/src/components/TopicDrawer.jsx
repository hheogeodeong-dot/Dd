import { motion, AnimatePresence } from 'framer-motion';
import { X } from 'lucide-react';

export default function TopicDrawer({ open, onClose, topics, active, onSelect, footer }) {
  return (
    <AnimatePresence>
      {open ? (
        <>
          <motion.div
            key="scrim"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            onClick={onClose}
            className="fixed inset-0 z-50 bg-foreground/30 backdrop-blur-[2px]"
          />
          <motion.aside
            key="panel"
            initial={{ x: '-100%' }}
            animate={{ x: 0 }}
            exit={{ x: '-100%' }}
            transition={{ duration: 0.4, ease: [0.76, 0, 0.24, 1] }}
            className="fixed inset-y-0 left-0 z-50 flex w-[86%] max-w-sm flex-col border-r border-border bg-background"
          >
            <div className="flex items-center justify-between border-b border-border px-6 py-5">
              <span className="text-[10px] uppercase tracking-[0.32em] text-muted-foreground">주제</span>
              <button
                type="button"
                onClick={onClose}
                className="p-1 text-muted-foreground transition-colors hover:text-foreground"
                aria-label="닫기"
              >
                <X className="h-5 w-5" strokeWidth={1.5} />
              </button>
            </div>

            <nav className="flex-1 overflow-y-auto px-6 py-8">
              <ul className="space-y-1">
                {topics.map((item) => {
                  const isActive = item.name === active;
                  return (
                    <li key={item.name}>
                      <button
                        type="button"
                        onClick={() => {
                          onSelect(item.name);
                          onClose();
                        }}
                        className={`group flex w-full items-baseline justify-between border-b border-border/60 py-4 text-left transition-colors ${
                          isActive ? 'text-foreground' : 'text-muted-foreground hover:text-foreground'
                        }`}
                      >
                        <span className="flex items-baseline gap-3">
                          <span
                            className={`h-[1px] transition-all duration-300 ${
                              isActive ? 'w-5 bg-brand' : 'w-0 bg-transparent group-hover:w-3 group-hover:bg-foreground'
                            }`}
                          />
                          <span className="font-heading text-[19px] tracking-tight">{item.name}</span>
                        </span>
                        <span className="font-mono text-[10px] tracking-[0.16em] text-muted-foreground">
                          {String(item.count).padStart(2, '0')}
                        </span>
                      </button>
                    </li>
                  );
                })}
              </ul>
            </nav>

            {footer ? <div className="border-t border-border px-6 py-5">{footer}</div> : null}
          </motion.aside>
        </>
      ) : null}
    </AnimatePresence>
  );
}