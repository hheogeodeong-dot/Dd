import { Link } from 'react-router-dom';
import moment from 'moment';
import 'moment/locale/ko';

moment.locale('ko');

function excerptOf(content = '') {
  const flat = content.replace(/\s+/g, ' ').trim();
  return flat.length > 140 ? `${flat.slice(0, 140)}…` : flat;
}

export default function PostCard({ post }) {
  return (
    <Link
      to={`/post/${post.id}`}
      className="group block border border-border px-5 py-6 transition-colors duration-300 hover:border-foreground/50 sm:px-8 sm:py-8"
    >
      <div className="flex items-center gap-3 text-[10px] tracking-[0.16em] text-muted-foreground">
        <span className="text-brand">{post.topic || '기록'}</span>
        <span className="h-[1px] w-4 bg-border" />
        <span className="font-mono">{moment(post.created_date).format('YY.MM.DD')}</span>
      </div>

      <h2 className="mt-4 font-heading text-[22px] font-semibold leading-[1.4] tracking-tight transition-colors group-hover:text-foreground sm:text-[27px]">
        {post.title}
      </h2>

      {post.content ? (
        <p className="mt-2.5 max-w-2xl text-[14px] leading-[1.85] text-muted-foreground sm:text-[15px]">
          {excerptOf(post.content)}
        </p>
      ) : null}
    </Link>
  );
}