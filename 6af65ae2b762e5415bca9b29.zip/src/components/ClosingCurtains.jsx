export default function ClosingCurtains({ active }) {
  const panel =
    'pointer-events-none fixed inset-x-0 z-[60] h-1/2 bg-splash transition-transform duration-700 ease-[cubic-bezier(0.76,0,0.24,1)]';

  return (
    <>
      <div
        className={`${panel} top-0 ${active ? 'translate-y-0' : '-translate-y-full'}`}
      />
      <div
        className={`${panel} bottom-0 ${active ? 'translate-y-0' : 'translate-y-full'}`}
      />
    </>
  );
}