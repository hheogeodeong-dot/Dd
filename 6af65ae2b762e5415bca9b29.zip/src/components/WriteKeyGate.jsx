import { useState } from 'react';
import { Loader2 } from 'lucide-react';

export default function WriteKeyGate({ onUnlock }) {
  const [value, setValue] = useState('');
  const [error, setError] = useState('');
  const [checking, setChecking] = useState(false);

  const submit = (event) => {
    event.preventDefault();
    if (checking) return;
    setChecking(true);
    setError('');
    if (value.trim() === 'lxn1ux1e!') {
      onUnlock();
      return;
    }
    setError('열쇠가 맞지 않습니다.');
    setChecking(false);
  };

  return (
    <div className="mt-16 sm:mt-24">
      <span className="text-[10px] tracking-[0.22em] text-muted-foreground">열쇠</span>
      <form onSubmit={submit} className="mt-6 max-w-sm">
        <input
          type="password"
          value={value}
          onChange={(event) => {
            setValue(event.target.value);
            setError('');
          }}
          placeholder="글 쓰기 열쇠"
          autoFocus
          className="w-full border-0 border-b border-border bg-transparent pb-3 text-[16px] tracking-[0.1em] text-foreground placeholder:text-muted-foreground/50 focus:border-foreground focus:outline-none"
        />
        {error ? <p className="mt-3 text-[13px] text-destructive">{error}</p> : null}
        <button
          type="submit"
          disabled={checking || !value}
          className="mt-8 inline-flex items-center gap-2 border border-foreground px-6 py-3 text-[11px] tracking-[0.2em] transition-colors hover:bg-foreground hover:text-background disabled:opacity-40"
        >
          {checking ? <Loader2 className="h-3.5 w-3.5 animate-spin" strokeWidth={1.5} /> : null}
          열기
        </button>
      </form>
    </div>
  );
}